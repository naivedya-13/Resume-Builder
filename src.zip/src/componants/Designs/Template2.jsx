import React from 'react'

const Template2 = () => {
  return (
    <div>Template2</div>
  )
}

export default Template2