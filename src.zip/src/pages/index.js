export {default as HomeScreen} from "./HomeScreen";
export {default as Authentication} from "./Authentication";
export {default as CreateTemplate} from "./CreateTemplate";
export {default as CreateResume} from "./CreateResume";
export {default as UserProfile} from "./UserProfile";
export {default as TemplateDesignPinD}  from "./TemplateDesignPinD"