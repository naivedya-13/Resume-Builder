export {default as App} from "./App";
export {default as Footer} from "./Footer";
export {default as HomeConatiner} from "./HomeContainer";