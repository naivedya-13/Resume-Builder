// images
export { default as Logo } from "./img/logo.png";
export { default as NoData } from "./img/nodata.gif";

export { default as TemplateOne } from "./img/designs/TemplateOne/Template1.png";
export { default as TemplateTwo } from "./img/designs/TemplateTwo/Template2.png";
